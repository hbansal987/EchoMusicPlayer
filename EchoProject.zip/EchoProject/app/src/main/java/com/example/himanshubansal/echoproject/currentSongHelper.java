package com.example.himanshubansal.echoproject;

public class currentSongHelper {
    public String songArtist=null;
    public String songTitle=null;
    public String songPath= null;
    public long songId= 0;
    public int currentPosition= 0;
    public Boolean isPlaying= false;
    public Boolean isloop= false;
    public Boolean isShuffle= false;
    public int trackPosition= 0;
}
