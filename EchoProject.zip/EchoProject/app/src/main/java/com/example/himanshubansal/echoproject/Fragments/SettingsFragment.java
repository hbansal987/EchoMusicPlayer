package com.example.himanshubansal.echoproject.Fragments;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.example.himanshubansal.echoproject.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class SettingsFragment extends Fragment {

    Activity myActivity= null;
    public static String MY_PREFS_NAME= "ShakeFeature";
    Switch shakeSwitch= null;


    public SettingsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_settings, container, false);
        myActivity.setTitle("Settings");
        shakeSwitch= view.findViewById(R.id.switchShake);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        myActivity= (Activity) context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        myActivity= activity;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        SharedPreferences prefs= myActivity.getSharedPreferences(MY_PREFS_NAME,Context.MODE_PRIVATE);
        Boolean isAllowed= prefs.getBoolean("feature",false);
        if(isAllowed){
            shakeSwitch.setChecked(true);
        }
        else{
            shakeSwitch.setChecked(false);
        }

        shakeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    SharedPreferences s = myActivity.getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor= s.edit();
                    editor.putBoolean("feature",true);
                    //editor.putString("password",password.getText().toString());
                    editor.apply();
                }

                else{
                    SharedPreferences s = myActivity.getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor= s.edit();
                    editor.putBoolean("feature",false);
                    //editor.putString("password",password.getText().toString());
                    editor.apply();
                }
            }
        });

    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
    }
}
