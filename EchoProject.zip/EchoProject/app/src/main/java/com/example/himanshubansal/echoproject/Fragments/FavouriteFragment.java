package com.example.himanshubansal.echoproject.Fragments;


import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.himanshubansal.echoproject.Adapters.FavouriteAdapter;
import com.example.himanshubansal.echoproject.Databases.EchoDatabase;
import com.example.himanshubansal.echoproject.R;
import com.example.himanshubansal.echoproject.Songs;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class FavouriteFragment extends Fragment {

    Activity myActivity= null;

    TextView noFavourites = null;
    RelativeLayout nowPlayingButtonBar= null;
    ImageButton playpauseButton =null;
    TextView songTitle= null;
    RecyclerView recyclerView= null;
    static MediaPlayer mediaPlayer=null;
    EchoDatabase favouriteContent= null;

    ArrayList<Songs> refreshList= null;
    ArrayList<Songs> getListFromDataBase= null;

    public FavouriteFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_favourite, container, false);

        noFavourites= view.findViewById(R.id.nofavourites);
        myActivity.setTitle("Favourites");
        nowPlayingButtonBar= view.findViewById(R.id.hiddenBarFavScreen);
        songTitle= view.findViewById(R.id.songTitleFavScreen);
        playpauseButton= view.findViewById(R.id.playPauseButtonFav);
        recyclerView= view.findViewById(R.id.favouriteRecycler);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        myActivity= (Activity) context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        myActivity= activity;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        favouriteContent= new EchoDatabase(myActivity);
        display_favourite_by_searching();
        bottonSetup();


    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
    }

    public ArrayList<Songs> getSongsFromPhone(){

        ArrayList<Songs> arrayList = new ArrayList<Songs>();
        ContentResolver contentResolver= myActivity.getContentResolver();
        Uri songUri= MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor songCursor= contentResolver.query(songUri,null,null,null,null);
        if(songCursor != null && songCursor.moveToFirst()){
            int songId = songCursor.getColumnIndex(MediaStore.Audio.Media._ID);
            int songTitle = songCursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int songArtist = songCursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int songData = songCursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            int songDate = songCursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED);
            while(songCursor.moveToNext()){
                long currentId = songCursor.getLong(songId);
                String currentTitle = songCursor.getString(songTitle);
                String currentArtist = songCursor.getString(songArtist);
                String currentData = songCursor.getString(songData);
                long currentDate = songCursor.getLong(songDate);

                arrayList.add(new Songs(currentId,currentTitle,currentArtist,currentData,currentDate));

            }
        }
        return arrayList;
    }

    public void bottonSetup(){
        try{
            bottonBarClickHandler();
            songTitle.setText(SongPlayingFragment.currentSongHelper.songTitle);
            SongPlayingFragment.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    songTitle.setText(SongPlayingFragment.currentSongHelper.songTitle);

                }

            });

            if(SongPlayingFragment.mediaPlayer.isPlaying()){
                nowPlayingButtonBar.setVisibility(View.VISIBLE);
            }

            else{
                nowPlayingButtonBar.setVisibility(View.INVISIBLE);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void bottonBarClickHandler(){
        nowPlayingButtonBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle args= new Bundle();
                mediaPlayer= SongPlayingFragment.mediaPlayer;
                args.putString("songArtist", SongPlayingFragment.currentSongHelper.songArtist);
                args.putString("path", SongPlayingFragment.currentSongHelper.songPath);
                args.putString("songTitle", SongPlayingFragment.currentSongHelper.songTitle);
                args.putInt("songId", ((int) SongPlayingFragment.currentSongHelper.songId));
                args.putInt("songPosition",SongPlayingFragment.currentSongHelper.currentPosition);
                args.putParcelableArrayList("songData",SongPlayingFragment.fetchSongs);
                args.putString("FavBottomBar","success");

                SongPlayingFragment songPlayingFragment= new SongPlayingFragment();
                FragmentManager fm =((FragmentActivity) myActivity).getSupportFragmentManager();
                FragmentTransaction fragmentTransactions = fm.beginTransaction();

                songPlayingFragment.setArguments(args);
                fragmentTransactions.replace(R.id.details_fragment, songPlayingFragment);
                fragmentTransactions.addToBackStack("SongPlayingFragment");
                fragmentTransactions.commit();

                playpauseButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(SongPlayingFragment.currentSongHelper.isPlaying){
                            SongPlayingFragment.mediaPlayer.pause();
                            playpauseButton.setBackgroundResource(R.drawable.play_icon);
                        }
                        else{
                            SongPlayingFragment.mediaPlayer.start();
                            playpauseButton.setBackgroundResource(R.drawable.pause_icon);
                        }
                    }
                });


            }
        });
    }

    public void display_favourite_by_searching(){
        if(favouriteContent.checkSize() > 0){
            refreshList= new ArrayList<Songs>();
            getListFromDataBase= favouriteContent.queryDBList();
            ArrayList<Songs> fetchListFromDevice= null;
            fetchListFromDevice= getSongsFromPhone();
            if(fetchListFromDevice != null){
                for(int i=0;i<fetchListFromDevice.size()-1;i++){
                    for(int j =0;j<getListFromDataBase.size();j++){
                        if((getListFromDataBase.get(j)).songID == (fetchListFromDevice.get(i).songID)){
                            refreshList.add(getListFromDataBase.get(j));
                        }
                    }
                }
            }
            else{

            }

            if(refreshList==null){
                recyclerView.setVisibility(View.INVISIBLE);
                noFavourites.setVisibility(View.VISIBLE);
            }
            else{
                FavouriteAdapter favouriteAdapter= new FavouriteAdapter(refreshList,myActivity);
                LinearLayoutManager mLayoutManager = new LinearLayoutManager(myActivity);
                recyclerView.setLayoutManager(mLayoutManager);
                recyclerView.setItemAnimator(new DefaultItemAnimator());
                recyclerView.setAdapter(favouriteAdapter);
                recyclerView.setHasFixedSize(true);

            }
        }
        else{
            recyclerView.setVisibility(View.INVISIBLE);
            noFavourites.setVisibility(View.VISIBLE);
        }


    }
}
