package com.example.himanshubansal.echoproject.Adapters;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.himanshubansal.echoproject.Activities.MainActivity;
import com.example.himanshubansal.echoproject.Fragments.MainScreenFragment;
import com.example.himanshubansal.echoproject.Fragments.SongPlayingFragment;
import com.example.himanshubansal.echoproject.R;
import com.example.himanshubansal.echoproject.Songs;

import java.util.ArrayList;

public class MainScreenAdapter extends RecyclerView.Adapter<MainScreenAdapter.MyViewHolder> {

    ArrayList<Songs> songsDetails = null;
    Context mContext = null;

    public MainScreenAdapter(ArrayList<Songs> _songsDetails, Context _context){
        this.songsDetails= _songsDetails;
        this.mContext= _context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View itemView= layoutInflater.inflate(R.layout.row_custom_mainscreen_adapter,viewGroup,false);
        MainScreenAdapter.MyViewHolder returnThis= new MainScreenAdapter.MyViewHolder(itemView);
        return returnThis;

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int i) {
        final Songs songObject = songsDetails.get(i);
        myViewHolder.trackTitle.setText(songObject.songTitle);
        myViewHolder.trackArtist.setText(songObject.artist);
        myViewHolder.contentHolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Bundle args= new Bundle();
                args.putString("songArtist",songObject.artist);
                args.putString("path", songObject.songData);
                args.putString("songTitle", songObject.songTitle);
                args.putInt("songId", ((int) songObject.songID));
                args.putInt("songPosition",i);
                args.putParcelableArrayList("songData",songsDetails);


                SongPlayingFragment songPlayingFragment= new SongPlayingFragment();
                FragmentManager fm =((FragmentActivity) mContext).getSupportFragmentManager();
                FragmentTransaction fragmentTransactions = fm.beginTransaction();

                songPlayingFragment.setArguments(args);
                fragmentTransactions.replace(R.id.details_fragment, songPlayingFragment);
                fragmentTransactions.addToBackStack("SongPlayingFragment");
                fragmentTransactions.commit();


            }
        });
    }

    @Override
    public int getItemCount() {
        if(songsDetails==null){
            return 0;
        }
        else{
            return  songsDetails.size();
        }
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView trackTitle= null;
        TextView trackArtist= null;
        RelativeLayout contentHolder = null;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            trackTitle= itemView.findViewById(R.id.trackTitle);
            trackArtist= itemView.findViewById(R.id.trackArtist);
            contentHolder= itemView.findViewById(R.id.contentRow);
        }
    }
}
