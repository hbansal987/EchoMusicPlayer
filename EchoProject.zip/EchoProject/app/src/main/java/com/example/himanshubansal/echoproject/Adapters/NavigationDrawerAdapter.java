package com.example.himanshubansal.echoproject.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.himanshubansal.echoproject.Activities.MainActivity;
import com.example.himanshubansal.echoproject.Fragments.AboutUsFragment;
import com.example.himanshubansal.echoproject.Fragments.FavouriteFragment;
import com.example.himanshubansal.echoproject.Fragments.MainScreenFragment;
import com.example.himanshubansal.echoproject.Fragments.SettingsFragment;
import com.example.himanshubansal.echoproject.R;

import java.util.ArrayList;

import static com.example.himanshubansal.echoproject.Activities.MainActivity.drawerLayout;

public class NavigationDrawerAdapter extends RecyclerView.Adapter<NavigationDrawerAdapter.NavViewHolder> {

    ArrayList<String> contentList=null;
    Integer[] getImages;
    Context mContext=null;

    public NavigationDrawerAdapter(ArrayList<String> _contentList, Integer[] _getImages, Context _context){
        this.contentList=_contentList;
        this.getImages=_getImages;
        this.mContext= _context;
    }

    @NonNull
    @Override
    public NavViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View itemView= layoutInflater.inflate(R.layout.row_custom_navigationdrawer,viewGroup,false);
        NavViewHolder returnThis= new NavViewHolder(itemView);
        return returnThis;
    }

    @Override
    public void onBindViewHolder(@NonNull NavViewHolder navViewHolder, final int i) {
            navViewHolder.icon_GET.setBackgroundResource(Integer.parseInt(getImages[i].toString()));
            navViewHolder.text_GET.setText(contentList.get(i));
            navViewHolder.contentHolder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(i==0){
                        MainScreenFragment mainScreenFragment= new MainScreenFragment();
                        FragmentManager fm =((MainActivity) mContext).getSupportFragmentManager();
                        FragmentTransaction fragmentTransactions = fm.beginTransaction();

                        fragmentTransactions.replace(R.id.details_fragment, mainScreenFragment);
                        fragmentTransactions.commit();
                    }

                    else if(i==1){
                        FavouriteFragment favouriteFragment= new FavouriteFragment();
                        FragmentManager fm =((MainActivity) mContext).getSupportFragmentManager();
                        FragmentTransaction fragmentTransactions = fm.beginTransaction();

                        fragmentTransactions.replace(R.id.details_fragment, favouriteFragment);
                        fragmentTransactions.commit();
                    }

                    else if(i==2){
                        SettingsFragment settingsFragment= new SettingsFragment();
                        FragmentManager fm =((MainActivity) mContext).getSupportFragmentManager();
                        FragmentTransaction fragmentTransactions = fm.beginTransaction();

                        fragmentTransactions.replace(R.id.details_fragment, settingsFragment);
                        fragmentTransactions.commit();
                    }

                    else if(i==3){
                        AboutUsFragment aboutUsFragment= new AboutUsFragment();
                        FragmentManager fm =((MainActivity) mContext).getSupportFragmentManager();
                        FragmentTransaction fragmentTransactions = fm.beginTransaction();

                        fragmentTransactions.replace(R.id.details_fragment, aboutUsFragment);
                        fragmentTransactions.commit();
                        }


                    drawerLayout.closeDrawer(Gravity.START,false);
                }
            });
    }

    @Override
    public int getItemCount() {
        return contentList.size();
    }

    class NavViewHolder extends RecyclerView.ViewHolder{

        ImageView icon_GET= null;
        TextView text_GET= null;
        RelativeLayout contentHolder=null;

        public NavViewHolder(@NonNull View itemView) {
            super(itemView);

            icon_GET= itemView.findViewById(R.id.icon_navdrawer);
            text_GET= itemView.findViewById(R.id.text_navdrawer);
            contentHolder= itemView.findViewById(R.id.nav_item_content_holder);
        }


    }
}
