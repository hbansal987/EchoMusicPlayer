package com.example.himanshubansal.echoproject.Databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.himanshubansal.echoproject.Songs;

import java.util.ArrayList;

public class   EchoDatabase extends SQLiteOpenHelper {

    static String DB_NAME = "FavouriteDatabase";
    static String TABLE_NAME = "FavouriteTable";
    static String COLUMN_ID = "SongID";
    static String COLUMN_SONG_TITLE = "SongTitle";
    static String COLUMN_SONG_ARTIST = "SongArtist";
    static String COLUMN_SONG_PATH = "SongPath";
    static int DB_VERSION=1;

    ArrayList<Songs> songList = new ArrayList<Songs>();

    public EchoDatabase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public EchoDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //THIS CREATES THE BASIC DATABASE USING QUERY METHOD.
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME + "( " + COLUMN_ID + " INTEGER," +
                COLUMN_SONG_ARTIST + " STRING," + COLUMN_SONG_TITLE + " STRING," + COLUMN_SONG_PATH + " STRING);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void storeAsFavourite(int id, String artist, String songTitle, String path) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_ID, id);
        contentValues.put(COLUMN_SONG_ARTIST, artist);
        contentValues.put(COLUMN_SONG_TITLE, songTitle);
        contentValues.put(COLUMN_SONG_PATH, path);

        db.insert(TABLE_NAME, null, contentValues);
        db.close();
    }

    public ArrayList<Songs> queryDBList() {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String query_params = "SELECT * FROM " + TABLE_NAME;
            Cursor cSor = db.rawQuery(query_params, null);
            if (cSor.moveToFirst()) {
                do {
                    int id = cSor.getInt(cSor.getColumnIndexOrThrow(COLUMN_ID));
                    String artist = cSor.getString(cSor.getColumnIndexOrThrow(COLUMN_SONG_ARTIST));
                    String title = cSor.getString(cSor.getColumnIndexOrThrow(COLUMN_SONG_TITLE));
                    String path = cSor.getString(cSor.getColumnIndexOrThrow(COLUMN_SONG_PATH));

                    songList.add(new Songs(id, title, artist, path, 0));
                }
                while (cSor.moveToNext());
            } else {
                return null;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return songList;
    }

    public Boolean checkifidExists(int _id){
        int storeId= -1090;
        SQLiteDatabase db = this.getReadableDatabase();
        String query_params = "SELECT * FROM " + TABLE_NAME + " WHERE SongId = '$_id'";
        Cursor cSor = db.rawQuery(query_params, null);
        if(cSor.moveToFirst()){
            do{
                storeId= cSor.getInt(cSor.getColumnIndexOrThrow(COLUMN_ID));

            }while(cSor.moveToNext());
        }
        else{
            return false;
        }
        return storeId!= -1090;
    }

    public void deleteFavourite(int _id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ID+"="+ _id,null);
        db.close();
    }

    public int checkSize(){
         int counter=0;
        SQLiteDatabase db = this.getReadableDatabase();
        String query_params = "SELECT * FROM " + TABLE_NAME ;
        Cursor cSor = db.rawQuery(query_params, null);
        if(cSor.moveToFirst()){
            do{
                //storeId= cSor.getInt(cSor.getColumnIndexOrThrow(COLUMN_ID));
                counter=counter+1;
            }while(cSor.moveToNext());
        }
        else{
            return 0;
        }
        return counter;
    }
}