package com.example.himanshubansal.echoproject;

import android.os.Parcel;
import android.os.Parcelable;

public class Songs implements Parcelable {
    public long songID;
    public String songTitle;
    public String artist;
    public String songData;
    public long dateAdded;

    public Songs(long songID, String songTitle,String artist,String songData,long dateAdded){
        this.songID=songID;
        this.songTitle=songTitle;
        this.artist=artist;
        this.songData=songData;
        this.dateAdded= dateAdded;
    }


    protected Songs(Parcel in) {
        songID = in.readLong();
        songTitle = in.readString();
        artist = in.readString();
        songData = in.readString();
        dateAdded = in.readLong();
    }

    public static final Creator<Songs> CREATOR = new Creator<Songs>() {
        @Override
        public Songs createFromParcel(Parcel in) {
            return new Songs(in);
        }

        @Override
        public Songs[] newArray(int size) {
            return new Songs[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(songID);
        dest.writeString(songTitle);
        dest.writeString(artist);
        dest.writeString(songData);
        dest.writeLong(dateAdded);
    }
}
