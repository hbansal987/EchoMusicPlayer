package com.example.himanshubansal.echoproject.Activities;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.LinearLayout;

import com.example.himanshubansal.echoproject.Adapters.NavigationDrawerAdapter;
import com.example.himanshubansal.echoproject.Fragments.MainScreenFragment;
import com.example.himanshubansal.echoproject.Fragments.SongPlayingFragment;
import com.example.himanshubansal.echoproject.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{

    public static DrawerLayout drawerLayout= null;
    public static NotificationManager notificationManager=null;
    public Notification trackNotificationBuilder= null;

    ArrayList<String> navigationDrawerIconList = new ArrayList<String>();
    Integer[] images_for_navdrawer= {R.drawable.navigation_allsongs,R.drawable.navigation_favorites,R.drawable.navigation_settings
    ,R.drawable.navigation_aboutus};
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar= findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout= findViewById(R.id.drawer_layout);

        navigationDrawerIconList.add("All Songs");
        navigationDrawerIconList.add("Favourites");
        navigationDrawerIconList.add("Settings");
        navigationDrawerIconList.add("About Us");

        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(MainActivity.this,drawerLayout,toolbar,
                R.string.navigation_drawer_open,R.string.navigation_drawer_close);

        drawerLayout.setDrawerListener(toggle);
        toggle.syncState();

        MainScreenFragment mainScreenFragment= new MainScreenFragment();

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        fragmentTransaction.add(R.id.details_fragment, mainScreenFragment,"MainScreenFragment");
        fragmentTransaction.commit();

        NavigationDrawerAdapter _navigationAdapter = new NavigationDrawerAdapter(navigationDrawerIconList,images_for_navdrawer,this);
        _navigationAdapter.notifyDataSetChanged();

        RecyclerView navigation_recycler_view = findViewById(R.id.navigation_recycler_view);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        navigation_recycler_view.setLayoutManager(mLayoutManager);
        DefaultItemAnimator mItemAnimator = new DefaultItemAnimator();
        navigation_recycler_view.setItemAnimator(mItemAnimator);
        navigation_recycler_view.setAdapter(_navigationAdapter);
        navigation_recycler_view.setHasFixedSize(true);

        Intent pintent = new Intent(MainActivity.this, MainActivity.class);
        PendingIntent pIn= PendingIntent.getActivity(MainActivity.this, (int) System.currentTimeMillis(),pintent,0);

        Notification.Builder trackNotificationBuilder= new Notification.Builder(this);
        trackNotificationBuilder.setContentTitle("A track is playing in the background");
        trackNotificationBuilder.setSmallIcon(R.drawable.echo_logo);
        trackNotificationBuilder.setContentIntent(pIn);
        trackNotificationBuilder.setOngoing(true);
        trackNotificationBuilder.setAutoCancel(true);
        trackNotificationBuilder.build();


        notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
    }

    @Override
    protected void onStart() {
        super.onStart();
        try{
            notificationManager.cancel(1999);
        }
        catch(Exception e){
        e.printStackTrace();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        try{
            notificationManager.cancel(1999);
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }



    @Override
    protected void onStop() {
        super.onStop();
        try{
            if(SongPlayingFragment.mediaPlayer.isPlaying()){
                notificationManager.notify(1999,trackNotificationBuilder);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

}
