package com.example.himanshubansal.echoproject.Fragments;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.cleveroad.audiovisualization.AudioVisualization;
import com.cleveroad.audiovisualization.GLAudioVisualizationView;
import com.example.himanshubansal.echoproject.Databases.EchoDatabase;
import com.example.himanshubansal.echoproject.R;
import com.example.himanshubansal.echoproject.Songs;
import com.example.himanshubansal.echoproject.currentSongHelper;

import java.util.ArrayList;
import java.util.Random;

import static android.content.Context.*;
import static com.example.himanshubansal.echoproject.Fragments.SettingsFragment.MY_PREFS_NAME;


/**
 * A simple {@link Fragment} subclass.
 */
public class SongPlayingFragment extends Fragment {


    static Activity myActivity= null;
    public static MediaPlayer mediaPlayer= null;
    static TextView startTimeText= null;
    static TextView endTimeText= null;
    public static ImageButton playpauseImageButton=null;
    static ImageButton previousImageButton= null;
    static ImageButton nextImageButton= null;
    static ImageButton loopImageButton= null;
    static ImageButton shuffleImageButton=null;
    static SeekBar seekbar= null;
    static TextView songArtistView=null;
    static TextView songTitleView=null;
    static int currentPosition=0;
    static ArrayList<Songs> fetchSongs= null;
    static AudioVisualization audioVisualization= null;
    static GLAudioVisualizationView glView= null;
    static String MY_PREFS_SHUFFLE= "Shuffle feature";
    static String MY_PREFS_LOOP= "Loop feature";
    public static SensorManager mSensorManager= null;
    public static SensorEventListener mSensorListener = null;

    static currentSongHelper currentSongHelper= null;

    static ImageButton fab=null;
    static EchoDatabase favouriteContent = null;

    Float mAcceleration = 0f;
    Float mAccelerationCurrent = 0f;
    Float mAccelerationLast = 0f;

    public SongPlayingFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_song_playing,container,false);
        myActivity.setTitle("Now Playing");
        seekbar= view.findViewById(R.id.seekBar);
        startTimeText= view.findViewById(R.id.startTime);
        endTimeText= view.findViewById(R.id.endTime);
        playpauseImageButton= view.findViewById(R.id.playpauseButton);
        nextImageButton= view.findViewById(R.id.nextButton);
        previousImageButton= view.findViewById(R.id.previousButton);
        loopImageButton= view.findViewById(R.id.loopButton);
        shuffleImageButton=view.findViewById(R.id.shuffleButton);
        songArtistView= view.findViewById(R.id.songArtist);
        songTitleView= view.findViewById(R.id.songTitle);
        glView= view.findViewById(R.id.visualizer_view);
        fab= view.findViewById(R.id.favouriteIcon);

        setHasOptionsMenu(true);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        audioVisualization= (AudioVisualization)glView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        myActivity=(Activity)context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        myActivity=activity;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        favouriteContent = new EchoDatabase(myActivity);
        currentSongHelper = new currentSongHelper();
        currentSongHelper.isPlaying = true;
        currentSongHelper.isloop = false;
        currentSongHelper.isShuffle = false;

        super.onActivityCreated(savedInstanceState);
        String path = null;
        String songTitle = null;
        String songArtist = null;
        long songId = 0;

        try {
            path = getArguments().getString("path");
            songTitle = getArguments().getString("songTitle");
            songArtist = getArguments().getString("songArtist");
            songId = getArguments().getInt("songId");
            currentPosition = getArguments().getInt("songPosition");
            fetchSongs = getArguments().getParcelableArrayList("songData");

            currentSongHelper.songPath = path;
            currentSongHelper.songTitle = songTitle;
            currentSongHelper.songArtist = songArtist;
            currentSongHelper.songId = songId;
            currentSongHelper.currentPosition = currentPosition;

            updateTextView(currentSongHelper.songArtist,currentSongHelper.songTitle);
        } catch (Exception e) {
            e.printStackTrace();
        }


        String fromMainBottomBar = getArguments().getString("MainBottomBar");
        if(fromMainBottomBar != null){
            mediaPlayer= MainScreenFragment.mediaPlayer;
        }
        else {

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            try {
                mediaPlayer.setDataSource(myActivity, Uri.parse(path));
                mediaPlayer.prepare();
            } catch (Exception e) {
                e.printStackTrace();
            }

            mediaPlayer.start();
        }
        if (currentSongHelper.isPlaying) {
            playpauseImageButton.setBackgroundResource(R.drawable.pause_icon);
        } else {
            playpauseImageButton.setBackgroundResource(R.drawable.play_icon);
        }

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                songComplete();
            }

        });

        String fromFavBottomBar = getArguments().getString("FavBottomBar");
        if(fromFavBottomBar != null){
            mediaPlayer= FavouriteFragment.mediaPlayer;
        }
        else {

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            try {
                mediaPlayer.setDataSource(myActivity, Uri.parse(path));
                mediaPlayer.prepare();
            } catch (Exception e) {
                e.printStackTrace();
            }

            mediaPlayer.start();
        }
        if (currentSongHelper.isPlaying) {
            playpauseImageButton.setBackgroundResource(R.drawable.pause_icon);
        } else {
            playpauseImageButton.setBackgroundResource(R.drawable.play_icon);
        }

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                songComplete();
            }

        });

        clickHandler();

        audioVisualization.linkTo(0);
        audioVisualization.linkTo(mediaPlayer);

        SharedPreferences prefsForShuffle = myActivity.getSharedPreferences(MY_PREFS_SHUFFLE,MODE_PRIVATE);
        Boolean isShuffleAllowed = prefsForShuffle.getBoolean("feature",false);
        if(isShuffleAllowed){
            currentSongHelper.isShuffle=true;
            currentSongHelper.isloop=false;
            shuffleImageButton.setBackgroundResource(R.drawable.shuffle_icon);
            loopImageButton.setBackgroundResource(R.drawable.loop_white_icon);
        }
        else{
            currentSongHelper.isShuffle=false;
            shuffleImageButton.setBackgroundResource(R.drawable.shuffle_white_icon);
        }

        SharedPreferences prefsForLoop = myActivity.getSharedPreferences(MY_PREFS_LOOP,MODE_PRIVATE);
        Boolean isLoopAllowed = prefsForLoop.getBoolean("feature",false);
        if(isLoopAllowed){
            currentSongHelper.isShuffle=false;
            currentSongHelper.isloop=true;
            shuffleImageButton.setBackgroundResource(R.drawable.shuffle_white_icon);
            loopImageButton.setBackgroundResource(R.drawable.loop_icon);
        }
        else{
            currentSongHelper.isloop=false;
            loopImageButton.setBackgroundResource(R.drawable.loop_white_icon);
        }

        if(favouriteContent.checkifidExists((int) currentSongHelper.songId)){
            fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_on));
        }
        else{
            fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_off));
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        audioVisualization.onResume();
        mSensorManager.registerListener(mSensorListener,mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    public void onPause() {
        audioVisualization.onPause();
        super.onPause();

        mSensorManager.unregisterListener(mSensorListener);
    }

    @Override
    public void onDestroyView() {
        audioVisualization.release();
        super.onDestroyView();

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSensorManager = (SensorManager) myActivity.getSystemService(SENSOR_SERVICE);
        mAcceleration=0.0f;
        mAccelerationCurrent=SensorManager.GRAVITY_EARTH;
        mAccelerationLast=SensorManager.GRAVITY_EARTH;
        bindShakeListener();
    }

    public static void songComplete(){
        if(currentSongHelper.isShuffle){

            playNext("shuffleYes");
            currentSongHelper.isPlaying=true;
        }
        else{
            if(currentSongHelper.isloop){
                currentPosition=currentPosition-1;
                playNext("shuffleNo");
                currentSongHelper.isPlaying=true;
            }
            else{
                playNext("shuffleNo");
                currentSongHelper.isPlaying=true;
            }
        }

        if(favouriteContent.checkifidExists((int) currentSongHelper.songId)){
            fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_on));
        }
        else{
            fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_off));
        }
    }



    public void clickHandler(){

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(favouriteContent.checkifidExists((int) currentSongHelper.songId)){
                    fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_off));
                    favouriteContent.deleteFavourite((int) currentSongHelper.songId);
                    Toast.makeText(myActivity, "Removed from favourites", Toast.LENGTH_SHORT).show();

                }
                else{
                    fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_on));
                    favouriteContent.storeAsFavourite((int) currentSongHelper.songId,currentSongHelper.songArtist,currentSongHelper.songTitle,currentSongHelper.songPath);
                    Toast.makeText(myActivity, "Song Added to Favourites", Toast.LENGTH_SHORT).show();
                }
            }
        });


        shuffleImageButton.setOnClickListener(new View.OnClickListener() {

            SharedPreferences s = myActivity.getSharedPreferences(MY_PREFS_SHUFFLE, MODE_PRIVATE);
            SharedPreferences.Editor editorShuffle= s.edit();

            SharedPreferences s1 = myActivity.getSharedPreferences(MY_PREFS_LOOP, MODE_PRIVATE);
            SharedPreferences.Editor editorLoop= s1.edit();

            @Override
            public void onClick(View v) {
                if(currentSongHelper.isShuffle){
                    currentSongHelper.isShuffle=false;
                    shuffleImageButton.setBackgroundResource(R.drawable.shuffle_white_icon);
                    editorShuffle.putBoolean("feature",false);
                    editorShuffle.apply();
                }

                else{
                    currentSongHelper.isShuffle=true;
                    currentSongHelper.isloop=false;
                    shuffleImageButton.setBackgroundResource(R.drawable.shuffle_icon);
                    loopImageButton.setBackgroundResource(R.drawable.loop_white_icon);
                    editorShuffle.putBoolean("feature",true);
                    editorShuffle.apply();
                    editorLoop.putBoolean("feature",false);
                    editorLoop.apply();

                }
            }
        });

        previousImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentSongHelper.isPlaying=true;
                if(currentSongHelper.isloop){
                    loopImageButton.setBackgroundResource(R.drawable.loop_white_icon);
                }
                playPrevious();
                if(favouriteContent.checkifidExists((int) currentSongHelper.songId)){
                    fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_on));
                }
                else{
                    fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_off));
                }

            }
        });

        playpauseImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mediaPlayer.isPlaying()){
                    mediaPlayer.pause();
                    currentSongHelper.isPlaying=false;
                    playpauseImageButton.setBackgroundResource(R.drawable.play_icon);
                }
                else{
                    mediaPlayer.start();
                    currentSongHelper.isPlaying=true;
                    playpauseImageButton.setBackgroundResource(R.drawable.pause_icon);
                }
            }
        });

        nextImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    currentSongHelper.isPlaying= true;
                    playpauseImageButton.setBackgroundResource(R.drawable.pause_icon);
                    if(currentSongHelper.isShuffle){
                        playNext("shuffleYes");
                    }
                    else{
                        playNext("shuffleNo");
                    }
            }
        });

        loopImageButton.setOnClickListener(new View.OnClickListener() {

            SharedPreferences s = myActivity.getSharedPreferences(MY_PREFS_SHUFFLE, MODE_PRIVATE);
            SharedPreferences.Editor editorShuffle= s.edit();

            SharedPreferences s1 = myActivity.getSharedPreferences(MY_PREFS_LOOP, MODE_PRIVATE);
            SharedPreferences.Editor editorLoop= s1.edit();


            @Override
            public void onClick(View v) {
                if(currentSongHelper.isloop){
                    currentSongHelper.isloop=false;
                    loopImageButton.setBackgroundResource(R.drawable.loop_white_icon);
                    editorLoop.putBoolean("feature",false);
                    editorLoop.apply();
                }
                else{
                    currentSongHelper.isloop=true;
                    currentSongHelper.isShuffle=false;
                    loopImageButton.setBackgroundResource(R.drawable.loop_icon);
                    shuffleImageButton.setBackgroundResource(R.drawable.shuffle_white_icon);

                    editorLoop.putBoolean("feature", true);
                    editorLoop.apply();

                    editorShuffle.putBoolean("feature",false);
                    editorShuffle.apply();
                }
            }
        });
    }


    public static void playNext(String check){
        if(check.equals("shuffleNo")){
            currentPosition= currentPosition+1;
        }
        else if(check.equals("shuffleYes")){
            Random rand= new Random();
           int randomPosition= rand.nextInt(fetchSongs.size()+1);
           currentPosition=randomPosition;

        }

        if(currentPosition == fetchSongs.size()){
            currentPosition=0;
        }

        currentSongHelper.isloop=false;
        Songs nextSong = fetchSongs.get(currentPosition);
        currentSongHelper.songPath= nextSong.songData;
        currentSongHelper.songTitle=nextSong.songTitle;
        currentSongHelper.songArtist= nextSong.artist;
        currentSongHelper.songId=nextSong.songID;
        currentSongHelper.currentPosition= currentPosition;
        mediaPlayer.reset();

        updateTextView(currentSongHelper.songArtist,currentSongHelper.songTitle);
        try{
            mediaPlayer.setDataSource(myActivity,Uri.parse(currentSongHelper.songPath));
            mediaPlayer.prepare();
            mediaPlayer.start();
        }catch (Exception e){
            e.printStackTrace();
        }
        if(favouriteContent.checkifidExists((int) currentSongHelper.songId)){
            fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_on));
        }
        else{
            fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_off));
        }
    }

    public static void playPrevious(){


        currentPosition=currentPosition-1;
        if(currentPosition == -1){
            currentPosition=0;
        }

        if(currentSongHelper.isPlaying){
            playpauseImageButton.setBackgroundResource(R.drawable.pause_icon);
        }
        else{
            playpauseImageButton.setBackgroundResource(R.drawable.play_icon);
        }

        currentSongHelper.isloop=false;
        Songs nextSong = fetchSongs.get(currentPosition);
        currentSongHelper.songPath= nextSong.songData;
        currentSongHelper.songTitle=nextSong.songTitle;
        currentSongHelper.songArtist= nextSong.artist;
        currentSongHelper.songId=nextSong.songID;
        currentSongHelper.currentPosition= currentPosition;
        mediaPlayer.reset();
        updateTextView(currentSongHelper.songArtist,currentSongHelper.songTitle);
        try{
            mediaPlayer.setDataSource(myActivity,Uri.parse(currentSongHelper.songPath));
            mediaPlayer.prepare();
            mediaPlayer.start();
        }catch (Exception e){
            e.printStackTrace();
        }
        if(favouriteContent.checkifidExists((int) currentSongHelper.songId)){
            fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_on));
        }
        else{
            fab.setImageDrawable(ContextCompat.getDrawable((myActivity),R.drawable.favorite_off));
        }
    }

    public static void updateTextView(String songArtist, String songTitle){
        songTitleView.setText(songTitle);
        songArtistView.setText(songArtist);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.song_playing_menu,menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        MenuItem item= menu.findItem(R.id.action_redirect);
        item.setVisible(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.action_redirect){
            myActivity.onBackPressed();
            return false;
        }

        return false;
    }

    public void bindShakeListener(){
        mSensorListener= new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                    float x= event.values[0];
                    float y= event.values[1];
                    float z= event.values[2];
                mAccelerationLast=mAccelerationCurrent;
                Double d= Double.valueOf(x*x +y*y +z*z);
                mAccelerationCurrent= (float)Math.sqrt(d);

                Float delta= mAccelerationCurrent-mAccelerationLast;
                mAcceleration= mAcceleration*0.9f +delta;

                if(mAcceleration > 12){
                    SharedPreferences s = myActivity.getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);
                    Boolean val= s.getBoolean("feature",false);
                    if(val){
                        playPrevious();
                    }
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };
    }


}
