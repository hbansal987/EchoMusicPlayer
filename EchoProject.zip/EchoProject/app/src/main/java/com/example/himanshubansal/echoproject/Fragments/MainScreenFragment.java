package com.example.himanshubansal.echoproject.Fragments;


import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.himanshubansal.echoproject.Adapters.MainScreenAdapter;
import com.example.himanshubansal.echoproject.R;
import com.example.himanshubansal.echoproject.Songs;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class MainScreenFragment extends Fragment {

    ArrayList<Songs> getSongList= null;
    RelativeLayout nowPlayingBottomBar = null;
    ImageButton playPauseButton= null;
    TextView songTitle= null;
    RelativeLayout visibleLayout= null;
    RelativeLayout noSongs= null;
    RecyclerView recyclerView= null;
    Activity myActivity=null;
    MainScreenAdapter _mainScreenAdapter=null;

    public static RelativeLayout nowPlayingButtonBar= null;
    static MediaPlayer mediaPlayer=null;

    public MainScreenFragment() {
        // Required empty public constructor
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getSongList= getSongsFromPhone();
        _mainScreenAdapter= new MainScreenAdapter(getSongList,myActivity);
        LinearLayoutManager linearLayoutManager= new LinearLayoutManager(myActivity);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(_mainScreenAdapter);
        nowPlayingBottomBar.setVisibility(View.VISIBLE);
        bottonSetup();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_main_screen,container,false);
        visibleLayout= view.findViewById(R.id.visibleLayout);
        noSongs= view.findViewById(R.id.noSongs);
        nowPlayingBottomBar= view.findViewById(R.id.hiddenBarMainScreen);
        songTitle= view.findViewById(R.id.songTitleMainScreen);
        playPauseButton= view.findViewById(R.id.playPauseButtonMain);
        recyclerView= view.findViewById(R.id.ContentMain);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        myActivity= (Activity) context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        myActivity=activity;
    }

    public ArrayList<Songs> getSongsFromPhone(){

        ArrayList<Songs> arrayList = new ArrayList<Songs>();
        ContentResolver contentResolver= myActivity.getContentResolver();
        Uri songUri= MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor songCursor= contentResolver.query(songUri,null,null,null,null);
        if(songCursor != null && songCursor.moveToFirst()){
            int songId = songCursor.getColumnIndex(MediaStore.Audio.Media._ID);
            int songTitle = songCursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int songArtist = songCursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int songData = songCursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            int songDate = songCursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED);
            while(songCursor.moveToNext()){
                long currentId = songCursor.getLong(songId);
                String currentTitle = songCursor.getString(songTitle);
                String currentArtist = songCursor.getString(songArtist);
                String currentData = songCursor.getString(songData);
                long currentDate = songCursor.getLong(songDate);

                arrayList.add(new Songs(currentId,currentTitle,currentArtist,currentData,currentDate));

            }
        }
        return arrayList;
    }

    public void bottonSetup(){
        try{
            bottonBarClickHandler();
            songTitle.setText(SongPlayingFragment.currentSongHelper.songTitle);
            SongPlayingFragment.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    songTitle.setText(SongPlayingFragment.currentSongHelper.songTitle);

                }

            });

            if(SongPlayingFragment.mediaPlayer.isPlaying()){
                nowPlayingButtonBar.setVisibility(View.VISIBLE);
            }

            else{
                nowPlayingButtonBar.setVisibility(View.INVISIBLE);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void bottonBarClickHandler(){
        nowPlayingButtonBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle args= new Bundle();
                mediaPlayer= SongPlayingFragment.mediaPlayer;
                args.putString("songArtist", SongPlayingFragment.currentSongHelper.songArtist);
                args.putString("path", SongPlayingFragment.currentSongHelper.songPath);
                args.putString("songTitle", SongPlayingFragment.currentSongHelper.songTitle);
                args.putInt("songId", ((int) SongPlayingFragment.currentSongHelper.songId));
                args.putInt("songPosition",SongPlayingFragment.currentSongHelper.currentPosition);
                args.putParcelableArrayList("songData",SongPlayingFragment.fetchSongs);
                args.putString("MainBottomBar","success");

                SongPlayingFragment songPlayingFragment= new SongPlayingFragment();
                FragmentManager fm =((FragmentActivity) myActivity).getSupportFragmentManager();
                FragmentTransaction fragmentTransactions = fm.beginTransaction();

                songPlayingFragment.setArguments(args);
                fragmentTransactions.replace(R.id.details_fragment, songPlayingFragment);
                fragmentTransactions.addToBackStack("SongPlayingFragment");
                fragmentTransactions.commit();

                playPauseButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(SongPlayingFragment.currentSongHelper.isPlaying){
                            SongPlayingFragment.mediaPlayer.pause();
                            playPauseButton.setBackgroundResource(R.drawable.play_icon);
                        }
                        else{
                            SongPlayingFragment.mediaPlayer.start();
                            playPauseButton.setBackgroundResource(R.drawable.pause_icon);
                        }
                    }
                });

            }
        });
    }
}
