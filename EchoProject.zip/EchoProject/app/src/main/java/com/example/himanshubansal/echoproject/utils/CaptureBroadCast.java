package com.example.himanshubansal.echoproject.utils;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;

import com.example.himanshubansal.echoproject.Activities.MainActivity;
import com.example.himanshubansal.echoproject.Fragments.SongPlayingFragment;
import com.example.himanshubansal.echoproject.R;

public class CaptureBroadCast extends BroadcastReceiver {
    @Override
    public void onReceive(Context context,Intent intent) {
        if(intent.getAction()==Intent.ACTION_NEW_OUTGOING_CALL){
            try {
                if (SongPlayingFragment.mediaPlayer.isPlaying()) {
                    MainActivity.notificationManager.cancel(1999);
                    SongPlayingFragment.mediaPlayer.pause();
                    SongPlayingFragment.playpauseImageButton.setBackgroundResource(R.drawable.play_icon);
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }

        else{
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Service.TELEPHONY_SERVICE);
            if(tm.getCallState()==TelephonyManager.CALL_STATE_RINGING){
                try {
                    if (SongPlayingFragment.mediaPlayer.isPlaying()) {
                        SongPlayingFragment.mediaPlayer.pause();
                        MainActivity.notificationManager.cancel(1999);
                        SongPlayingFragment.playpauseImageButton.setBackgroundResource(R.drawable.play_icon);
                    }
                }
            catch(Exception e){
                    e.printStackTrace();
                }
            }
            else{

            }

        }
    }
}
