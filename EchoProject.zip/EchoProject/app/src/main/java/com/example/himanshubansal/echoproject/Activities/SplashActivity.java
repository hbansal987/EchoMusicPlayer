package com.example.himanshubansal.echoproject.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.himanshubansal.echoproject.R;

public class SplashActivity extends AppCompatActivity {

    String[] permissionString = {android.Manifest.permission.READ_EXTERNAL_STORAGE,
            android.Manifest.permission.MODIFY_AUDIO_SETTINGS,android.Manifest.permission.READ_PHONE_STATE,android.Manifest.permission.PROCESS_OUTGOING_CALLS
            ,android.Manifest.permission.RECORD_AUDIO};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        if(!hasPermission(SplashActivity.this,permissionString)){

            ActivityCompat.requestPermissions(SplashActivity.this,permissionString,131);
        }
        else{
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                        Intent i = new Intent(SplashActivity.this, MainActivity.class);
                        SplashActivity.this.startActivity(i);
                        SplashActivity.this.finish();
                }
            },1000);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode==131){
            if(grantResults.length!=0 && grantResults[0]== PackageManager.PERMISSION_GRANTED
            && grantResults[1]== PackageManager.PERMISSION_GRANTED
            && grantResults[2]== PackageManager.PERMISSION_GRANTED
            && grantResults[3]== PackageManager.PERMISSION_GRANTED
            && grantResults[4]== PackageManager.PERMISSION_GRANTED
            ){
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent i = new Intent(SplashActivity.this, MainActivity.class);
                        SplashActivity.this.startActivity(i);
                        SplashActivity.this.finish();
                    }
                },1000);
            }
            else{
                Toast.makeText(this, "Please Grant All The Permissions", Toast.LENGTH_SHORT).show();
                this.finish();
            }
        }

        else{
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
            this.finish();
            }

    }

    public boolean hasPermission(Context context, String[] permission){
        boolean hasAllPermission= true;
        for(int i=0;i<permission.length;i++){
            int res= context.checkCallingOrSelfPermission(permission[i]);
            if( res != PackageManager.PERMISSION_GRANTED){
                hasAllPermission=false;
            }

        }
        return hasAllPermission;
    }



}
